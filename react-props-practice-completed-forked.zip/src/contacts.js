const contacts = [
  {
    id: 1,
    name: "Beyonce",
    imgURL:
      "https://cdn.britannica.com/59/204159-050-5055F2A9/Beyonce-2013.jpg",
    phone: "+123 456 789",
    email: "b@beyonce.com",
  },
  {
    id: 2,
    name: "Jack Bauer",
    imgURL:
      "https://kids.kiddle.co/images/thumb/b/bc/Jack_Bauer1.jpg/300px-Jack_Bauer1.jpg",
    phone: "+987 654 321",
    email: "jack@nowhere.com",
  },
  {
    id: 3,
    name: "Chuck Norris",
    imgURL:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Chuck_Norris_May_2015.jpg/220px-Chuck_Norris_May_2015.jpg",
    phone: "+918 372 574",
    email: "gmail@chucknorris.com",
  },
];

export default contacts;
