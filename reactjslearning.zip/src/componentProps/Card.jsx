import React from "react";

function Card(props) {
  return (
    <div className="contact-card">
      <div className="profile">
        <h2 className="name">{props.name}</h2>
        <img className="contact-pic" src={props.image} />
      </div>
      <div className="info">
        <p>{props.phn}</p>
        <p>{props.email}</p>
      </div>
    </div>
  );
}

export default Card;
