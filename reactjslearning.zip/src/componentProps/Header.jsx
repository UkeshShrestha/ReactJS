import React from "react";

function Header() {
  return (
    <div>
      <header>
        <h1>My Contacts</h1>
      </header>
    </div>
  );
}

export default Header;
