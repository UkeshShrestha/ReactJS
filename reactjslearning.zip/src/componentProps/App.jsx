import React from "react";
import Header from "./Header";
import Card from "./Card";

function App() {
  return (
    <div>
      <Header />
      <Card
        name="Geralt"
        image="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRWUd6YfAoScDbve1s5efBrC04SxOppXjnLx-muPj_C-I6h_oCzPMxidZ02nND5-AtgsPw&usqp=CAU"
        phn="+977 9808144586"
        email="witcher@Kaer.com"
      />
      <Card
        name="Booker"
        image="https://i1.sndcdn.com/artworks-000053859587-7iqfq5-t500x500.jpg"
        phn="+977 9851056988"
        email="kindly@rapture.com"
      />
      <Card
        name="Jhonny"
        image="https://i1.sndcdn.com/artworks-rA6XhLTzSebezV9Y-Lp4QSw-t500x500.jpg"
        phn="+977 9808265478"
        email="silverhand@nightcity.com"
      />
    </div>
  );
}

export default App;
