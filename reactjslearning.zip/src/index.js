// import React from "react";
// import ReactDOM from "react-dom";

// ReactDOM.render(What to show, where to show it);

// ReactDOM.render(<h1>Hellow World!</h1>, document.getElementById("root"));  render allows only takes single html elements

// ReactDOM.render(
//   <div>
//     <h1>Hellow World!</h1>
//     <p> This is a paragraph </p>
//   </div>,
//   document.getElementById("root")
// );

//************************************************************************************************ */

//CHALLANGE 1

// import React from "react";
// import ReactDOM from "react-dom";

// ReactDOM.render(
//   <div>
//     <h1>My Favourite Games</h1>
//     <ul>
//       <li>Witcher 3</li>
//       <li>Bioshock</li>
//       <li>Fallout</li>
//     </ul>
//   </div>,
//   document.getElementById("root")
// );

//**************************************************************************************************** */

//HTML IN JS AND JS INSIDE HTML by using { }

// import React from "react";
// import ReactDOM from "react-dom";

// const name = "Angela";

// ReactDOM.render(<h1>Hello {name}!</h1>, document.getElementById("root"));

//*********************************************************************************************** */

//CHALLANGE2

// import React from "react";
// import ReactDOM from "react-dom";

// const name = "Ukesh";
// const luckyNumber = Math.floor(Math.random() * 10) + 1;

// ReactDOM.render(
//   <div>
//     <h1>Hello {name}</h1>
//     <p>Your lucky number is {luckyNumber}</p> ||| <p>Your lucky number is {Math.floor(Math.random() * 10) + 1}</p>
//   </div>,
//   document.getElementById("root")
// );

//**************************************************************************************************8 */

// CHALLANGE 3

// import React from "react";
// import ReactDOM from "react-dom";

// const firstName = "Ukesh";
// const lastName = "Shrestha";
// const luckyNumber = Math.floor(Math.random() * 10) + 1;

// ReactDOM.render(
//   <div>
//     <h1>Hello {firstName + " " + lastName}</h1> |||<h1>Hello {firstName} {lastName}</h1>
//     <p>Your lucky number is {luckyNumber}</p>
//   </div>,
//   document.getElementById("root")
// );

//*********************************************************************************************88**** */

//CHALLANGE 3

// import React from "react";
// import ReactDOM from "react-dom";

// const name = "Ukesh Shrestha";
// var currentDate = new Date();
// const copyrightYear = currentDate.getFullYear();

// ReactDOM.render(
//   <div>
//     <p>Created by: {name}</p>
//     <p>Copyright: {copyrightYear}</p>
//   </div>,
//   document.getElementById("root")
// );

//***************************************************************************************************** */

// import React from "react";
// import { createRoot } from "react-dom/client";

// const rootElement = document.getElementById("root");
// const root = createRoot(rootElement);

// root.render(
//   <div>
//     <h1 className="heading" contentEditable="true" spellCheck="false">
//       My Favourite Games
//     </h1>
//     <ul>
//       <li>Witcher 3</li>
//       <li>Bioshock</li>
//       <li>Fallout</li>
//     </ul>
//   </div>
// );

//****************************************************************************************************** */

//IMAGES

// import React from "react";
// import { createRoot } from "react-dom/client";

// const rootElement = document.getElementById("root");
// const root = createRoot(rootElement);

// root.render(
//   <div>
//     <h1 className="heading">My Favourite Games</h1>
//     <div>
//       <img
//         className="food-img"
//         src="https://image.api.playstation.com/vulcan/ap/rnd/202211/0711/kh4MUIuMmHlktOHar3lVl6rY.png"
//         alt="witcher3"
//       />
//       <img
//         className="food-img"
//         src="https://cdn1.epicgames.com/offer/e9e3ee13329f434f94105e6ec63435e0/EGS_BioShockRemastered_MassMediaGames_S1_2560x1440-cb7067c24252c5602497ab42fc488eed"
//         alt="bioshock"
//       />
//       <img
//         className="food-img"
//         src="https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/22300/capsule_616x353.jpg?t=1665072658"
//         alt="fallout3"
//       />
//     </div>
//   </div>
// );

//******************************************************************************************************************************************************** */

// import React from "react";
// import { createRoot } from "react-dom/client";

// const rootElement = document.getElementById("root");
// const root = createRoot(rootElement);

// const img = "https://picsum.photos/200/300";

// root.render(
//   <div>
//     <h1 className="heading">My Favourite Games</h1>
//     <img src={img + "?grayscale"} />
//   </div>
// );

//*********************************************************************************************************************************************************************/

// import React from "react";
// import { createRoot } from "react-dom/client";

// const rootElement = document.getElementById("root");
// const root = createRoot(rootElement);

// root.render(
//   <div>
//     <h1>Hello World!!</h1>
//   </div>
// );

// ********************************************************************************************************* */

// / CHALLANGE 5

// import React from "react";
// import { createRoot } from "react-dom/client";

// const rootElement = document.getElementById("root");
// const root = createRoot(rootElement);

// const currentTime = new Date().getHours();

// let greeting;
// let theme;
// if (currentTime < 12) {
//   greeting = "Good morning";
//   theme = { color: "red" };
// } else if (currentTime < 18) {
//   greeting = "Good afternoon";
//   theme = { color: "green" };
// } else {
//   greeting = "Good evening";
//   theme = { color: "blue" };
// }

// root.render(
//   <div>
//     <h1 className="heading" style={theme}>
//       {greeting}
//     </h1>
//   </div>
// );

//********************************************************************************************************************** */

// import React from "react";
// import { createRoot } from "react-dom/client";
// import App from "./components/App";

// const rootElement = document.getElementById("root");
// const root = createRoot(rootElement);

// root.render(
//   <div>
//     <App />
//   </div>
// );

//********************************************************************************* */

// import React from "react";
// import { createRoot } from "react-dom/client";
// import { add, multiply, subtract, divide } from "./components3/Calculator";

// const rootElement = document.getElementById("root");
// const root = createRoot(rootElement);

// root.render(
//   <ul>
//     <li>{add(1, 2)}</li>
//     <li>{multiply(2, 3)}</li>
//     <li>{subtract(7, 2)}</li>
//     <li>{divide(5, 2)}</li>
//   </ul>
// );

//************************************************************************************8 */

//PROPS

// import React from "react";
// import { createRoot } from "react-dom/client";
// import App from "./componentProps/App";

// const rootElement = document.getElementById("root");
// const root = createRoot(rootElement);

// root.render(<App />);

//********************************************************************************** */
