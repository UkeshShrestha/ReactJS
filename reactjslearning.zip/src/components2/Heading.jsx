import React from "react";

function Heading() {
  const currentTime = new Date().getHours();
  let greeting;
  let theme;
  if (currentTime < 12) {
    greeting = "Good morning";
    theme = { color: "red" };
  } else if (currentTime < 18) {
    greeting = "Good afternoon";
    theme = { color: "green" };
  } else {
    greeting = "Good evening";
    theme = { color: "blue" };
  }

  return (
    <h1 className="heading" style={theme}>
      {greeting}
    </h1>
  );
}

export default Heading;
