import React from "react";

function Heading() {
  return <h1>My Favourite Games</h1>;
}

export default Heading;
