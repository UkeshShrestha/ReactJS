import React from "react";

function List() {
  return (
    <ul>
      <li>Witcher 3</li>
      <li>Bioshock</li>
      <li>Fallout</li>
    </ul>
  );
}

export default List;
