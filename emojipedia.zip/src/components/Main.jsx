import React from "react";

function Dictionary(props) {
  return (
    <div className="card">
      <div className="emoji">{props.emoji}</div>
      <div className="Dictionary">
        <dl>
          <dt>{props.emojititle}</dt>
          <dd>{props.description}</dd>
        </dl>
      </div>
    </div>
  );
}

export default Dictionary;
