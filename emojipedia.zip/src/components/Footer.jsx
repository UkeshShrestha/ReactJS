import React from "react";

function copyrightYear() {
  const currentYear = new Date();
  const copyrightYear = currentYear.getFullYear();

  return <p>Copyright: {copyrightYear}</p>;
}

export default copyrightYear;
