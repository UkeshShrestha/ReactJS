import React from "react";
import Dictionary from "./Main";
import Footer from "./Footer";
import emojis from "../emoji";

function createDictonary(emoji) {
  return (
    <Dictionary
      key={emoji.id}
      id={emoji.id}
      emoji={emoji.emoji}
      emojititle={emoji.emojititle}
      description={emoji.description}
    />
  );
}

function App() {
  return (
    <div>
      <h1>
        <span>emojipedia</span>
      </h1>
      <dl className="dictionary">{emojis.map(createDictonary)}</dl>
      <Footer />
    </div>
  );
}

export default App;
