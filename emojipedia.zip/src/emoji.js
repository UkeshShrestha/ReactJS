const emojis = [
  {
    id: 1,
    emoji: "💪",
    emojititle: "Tense Biceps",
    description:
      "'You can do that!' or 'I feel strong! Arm with tense biceps. Also used in connection with doing sports, e.g the gym.",
  },
  {
    id: 2,
    emoji: "🙏",
    emojititle: "Person With Folded Hands",
    description:
      "Two hand pressed together, is currently very introverted, sayng a prayer, or hoping for enlightenment, is also used as a 'highfive' or to say thank you.",
  },
  {
    id: 3,
    emoji: "🤣",
    emojititle: "Rollong On The Floor, Laughing",
    description:
      "Huge glasses, awkward smile and buck teeth. Used humorously or ironically for nerds or to express how smart but funny dressed person with social deficits.",
  },
  {
    id: 3,
    emoji: "🤣",
    emojititle: "Rollong On The Floor, Laughing",
    description:
      "Huge glasses, awkward smile and buck teeth. Used humorously or ironically for nerds or to express how smart but funny dressed person with social deficits.",
  },
];

export default emojis;
