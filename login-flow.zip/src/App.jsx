import "./styles.css";
import Login from "./Login";

const loginStatus = false;

function renderCondition() {
  if (loginStatus === true) {
    return (
      <div className="header">
        <h1>LoggedIn</h1>
      </div>
    );
  } else {
    return <Login />;
  }
}

function App() {
  return <div>{renderCondition()}</div>;
}

export default App;
