import React, { useState } from "react";

function App() {
  const [headingText, setHeadingText] = useState("Hello");

  function click() {
    return setHeadingText("Submitted");
  }

  function mouseover() {
    document.querySelector("button").style.backgroundColor = "black";
  }

  function mouseout() {
    document.querySelector("button").style.backgroundColor = "white";
  }

  return (
    <div className="container">
      <h1>{headingText}</h1>
      <input type="text" placeholder="What's your name?" />
      <button onClick={click} onMouseOver={mouseover} onMouseOut={mouseout}>
        Submit
      </button>
    </div>
  );
}

export default App;

// import React, { useState } from "react";

// function App() {
//   const [headingText, setHeadingText] = useState("Hello");
//   const [isMouseOver, setMouseOver] = useState(false);

//   function click() {
//     return setHeadingText("Submitted");
//   }

//   function handleMouseOver() {
//     return setMouseOver(true);
//   }

//   function handleMouseOut() {
//     return setMouseOver(false);
//   }

//   return (
//     <div className="container">
//       <h1>{headingText}</h1>
//       <input type="text" placeholder="What's your name?" />
//       <button
//         onClick={click}
//         style={{ backgroundColor: isMouseOver ? "black" : "white" }}
//         onMouseOver={handleMouseOver}
//         onMouseOut={handleMouseOut}
//       >
//         Submit
//       </button>
//     </div>
//   );
// }
