const notes = [
  {
    id: 1,
    title: "xxx-xx",
    description: "xxx x xxxxxx x  xxxxxxx xxxx xxxxxxx xxxxxx",
  },
  {
    id: 1,
    title: "xx/xx/xxxx",
    description: "xxxxxxxxx xxxxxxxxx xxxxxxxx xxxxx x xxxxxxx xxxx",
  },
  {
    id: 1,
    title: "xx.xx.x.x.x",
    description: "xxx x xxxxxx x  xxxxxxx xxxx xxxxxxx xxxxx",
  },
  {
    id: 1,
    title: "xx-x-xx-x",
    description: "xxx x xxxxxx x  xxxxxxx xxxx xxxxxxx xxxxx",
  },
  {
    id: 1,
    title: "xx@ddxx",
    description: "xxx x xxxxxx x  xxxxxxx xxxx xxxxxxx xxxxx",
  },
  {
    id: 1,
    title: "xxxx#XXX#X",
    description: "xxx x xxxxxx x  xxxxxxx xxxx xxxxxxx xxxxx",
  },
];

export default notes;
