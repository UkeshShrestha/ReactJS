import React from "react";

function Note(props) {
  return (
    <div className="note-box">
      <h2 className="note-title">{props.title}</h2>
      <p>{props.description}</p>
    </div>
  );
}

export default Note;
