import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
import notes from "../notes";

function createNotes(notes) {
  return (
    <Note
      key={notes.id}
      id={notes.id}
      title={notes.title}
      description={notes.description}
    />
  );
}

function App() {
  return (
    <div>
      <Header />
      <p>{notes.map(createNotes)}</p>
      <Footer />
    </div>
  );
}

export default App;
