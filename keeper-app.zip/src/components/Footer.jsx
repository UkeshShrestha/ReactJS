import React from "react";

function Footer() {
  const currentDate = new Date();
  const copyrightYear = currentDate.getFullYear();
  return (
    <footer>
      <p>Copyright: {copyrightYear}</p>
    </footer>
  );
}

export default Footer;
