import React from "react";

function strike() {
  document.getElementById("root").style.textDecoration = "line-through";
}

function Unstrike() {
  document.getElementById("root").style.textDecoration = "none";
}

function App() {
  return (
    <div>
      <p>Buy Milk</p>
      <button onClick={strike}>Change to strike through</button>
      <button onClick={Unstrike}>Change to strike through</button>
    </div>
  );
}

export default App;
